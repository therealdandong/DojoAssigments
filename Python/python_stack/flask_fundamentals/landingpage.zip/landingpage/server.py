from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/ninjas')
def ninja():
    return render_template('ninjas.html')


@app.route('/dojos/new')
def dojo():

    return render_template('dojo.html')


@app.route('/dojos/new/result', methods=['POST'])
def result():
    name = request.form['name']
    email = request.form['email']
    return render_template('result.html',name=name,email=email)

app.run(debug=True)
